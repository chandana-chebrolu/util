﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace TrustMe.Models
{
    public partial class APIAppDbContext : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            #warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
            optionsBuilder.UseSqlServer(@"Data Source=HOUVDISQLDEV01;Initial Catalog=BlackKnightInternal_Test; user id=sa; password=Password@1; MultipleActiveResultSets=True");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Employee>(entity =>
            {
                entity.HasIndex(e => e.Ecode)
                    .HasName("UQ__Employee__7A63BD5520CC804E")
                    .IsUnique();
            });

            modelBuilder.Entity<EmployeeRole>(entity =>
            {
                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            });

            modelBuilder.Entity<Project>(entity =>
            {
                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            });
        }

        public virtual DbSet<CabRequest> CabRequest { get; set; }
        public virtual DbSet<Department> Department { get; set; }
        public virtual DbSet<Employee> Employee { get; set; }
        public virtual DbSet<EmployeeDepartment> EmployeeDepartment { get; set; }
        public virtual DbSet<EmployeeLeaveDetails> EmployeeLeaveDetails { get; set; }
        public virtual DbSet<EmployeeRole> EmployeeRole { get; set; }
        public virtual DbSet<EmployeeTaskExpertise> EmployeeTaskExpertise { get; set; }
        public virtual DbSet<Group> Group { get; set; }
        public virtual DbSet<LeaveMaster> LeaveMaster { get; set; }
        public virtual DbSet<LeaveTypes> LeaveTypes { get; set; }
        public virtual DbSet<Project> Project { get; set; }
        public virtual DbSet<Query> Query { get; set; }
        public virtual DbSet<Role> Role { get; set; }
        public virtual DbSet<ShiftReport> ShiftReport { get; set; }
        public virtual DbSet<Task> Task { get; set; }
        public virtual DbSet<TaskCategory> TaskCategory { get; set; }
        public virtual DbSet<TaskExpertise> TaskExpertise { get; set; }
        public virtual DbSet<UtilizationReport> UtilizationReport { get; set; }

        // Unable to generate entity type for table 'dbo.EmployeeLeaveInfo'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.HolidayList'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.LeaveStatus'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.LogData'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.ServiceLogData'. Please see the warning messages.
    }
}