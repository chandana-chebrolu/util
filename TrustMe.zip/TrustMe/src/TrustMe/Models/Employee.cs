﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TrustMe.Models
{
    public partial class Employee
    {
        public int Id { get; set; }
        [Required]
        [Column("ECode")]
        [MaxLength(20)]
        public string Ecode { get; set; }
        [Required]
        [MaxLength(20)]
        public string Password { get; set; }
        public int DeptId { get; set; }
        [Required]
        [Column(TypeName = "varchar(50)")]
        public string FirstName { get; set; }
        [Required]
        [Column(TypeName = "varchar(50)")]
        public string LastName { get; set; }
        [Column(TypeName = "date")]
        public DateTime? DateOfBirth { get; set; }
        [Column(TypeName = "date")]
        public DateTime? DateOfJoin { get; set; }
        [Column(TypeName = "varchar(100)")]
        public string EmailId { get; set; }
        [Column(TypeName = "varchar(20)")]
        public string MobileNumber { get; set; }
        [Column(TypeName = "varchar(20)")]
        public string AltMobileNumber { get; set; }
        public bool IsActive { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        [MaxLength(20)]
        public string CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }
        [MaxLength(20)]
        public string ModifiedBy { get; set; }
        public int? ProjectId { get; set; }
        public bool CanExport { get; set; }
        public string Address { get; set; }
        [Column(TypeName = "varchar(50)")]
        public string StgUserId { get; set; }
        [Column(TypeName = "varchar(50)")]
        public string PrdUserId { get; set; }
    }
}
