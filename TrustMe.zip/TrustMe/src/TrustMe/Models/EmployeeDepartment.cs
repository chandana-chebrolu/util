﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TrustMe.Models
{
    public partial class EmployeeDepartment
    {
        public int EmployeeDepartmentId { get; set; }
        [Column("ECode")]
        [MaxLength(20)]
        public string Ecode { get; set; }
        public int? DeptId { get; set; }
    }
}
