﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TrustMe.Models
{
    public partial class EmployeeLeaveDetails
    {
        [Key]
        public int EmployeeLeaveDetailId { get; set; }
        [Required]
        [Column("ECode")]
        [MaxLength(20)]
        public string Ecode { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime LeaveFromDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime LeaveToDate { get; set; }
        public int NumberOfDays { get; set; }
        [Column(TypeName = "varchar(20)")]
        public string LeaveStatus { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? StatusDate { get; set; }
        public bool? SentMailToManager { get; set; }
        [Column("SentMailToHR")]
        public bool? SentMailToHr { get; set; }
        [MaxLength(20)]
        public string ManagerId { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? MgrApprovedDate { get; set; }
        [Column("HRID")]
        [MaxLength(20)]
        public string Hrid { get; set; }
        [Column("HRApprovedDate", TypeName = "datetime")]
        public DateTime? HrapprovedDate { get; set; }
        [MaxLength(200)]
        public string ManagerComments { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime CreateDate { get; set; }
        [Required]
        [MaxLength(20)]
        public string CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }
        [MaxLength(20)]
        public string ModifiedBy { get; set; }
        public int LeaveType { get; set; }
        [MaxLength(200)]
        public string EmployeeComments { get; set; }
        public bool? IsHalfday { get; set; }
        [MaxLength(20)]
        public string CanceledBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CanceledDate { get; set; }
        [MaxLength(200)]
        public string CanceledComments { get; set; }
    }
}
