﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TrustMe.Models
{
    public partial class EmployeeRole
    {
        public int EmployeeRoleId { get; set; }
        [Required]
        [Column("ECode")]
        [MaxLength(20)]
        public string Ecode { get; set; }
        public int RoleId { get; set; }
        public bool? IsActive { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        [MaxLength(20)]
        public string CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }
        [MaxLength(20)]
        public string ModifiedBy { get; set; }
        [Required]
        [MaxLength(20)]
        public string LeadId { get; set; }
        [Required]
        [MaxLength(20)]
        public string ManagerId { get; set; }
        public bool? IsAdmin { get; set; }
    }
}
