﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TrustMe.Models
{
    public partial class EmployeeTaskExpertise
    {
        public int Id { get; set; }
        [Required]
        [Column("ECode")]
        [MaxLength(20)]
        public string Ecode { get; set; }
        [Column("EName", TypeName = "nchar(80)")]
        public string Ename { get; set; }
        public int? DeptId { get; set; }
        public int? TaskExpertiseId { get; set; }
        [Required]
        [MaxLength(20)]
        public string Status { get; set; }

        [ForeignKey("DeptId")]
        [InverseProperty("EmployeeTaskExpertise")]
        public virtual Department Dept { get; set; }
        [ForeignKey("TaskExpertiseId")]
        [InverseProperty("EmployeeTaskExpertise")]
        public virtual TaskExpertise TaskExpertise { get; set; }
    }
}
