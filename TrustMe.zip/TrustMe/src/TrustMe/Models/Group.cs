﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TrustMe.Models
{
    public partial class Group
    {
        public int GroupId { get; set; }
        [Required]
        [MaxLength(100)]
        public string GroupName { get; set; }
        [MaxLength(200)]
        public string TemplateName { get; set; }
        public bool IsActive { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        [MaxLength(20)]
        public string CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }
        [MaxLength(20)]
        public string ModifiedBy { get; set; }
    }
}
