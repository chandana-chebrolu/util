﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TrustMe.Models
{
    public partial class LeaveMaster
    {
        [Column("ECode")]
        [MaxLength(20)]
        [Key]
        public string Ecode { get; set; }
        public int? Year { get; set; }
        [Column(TypeName = "decimal")]
        public decimal? CarryForwardLeaves { get; set; }
        [Column(TypeName = "decimal")]
        public decimal? EncashedLeaves { get; set; }
        [Column(TypeName = "decimal")]
        public decimal? MonthlyAquiredLeaves { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }
    }
}
