﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TrustMe.Models
{
    public partial class Query
    {
        public int QueryId { get; set; }
        [MaxLength(50)]
        public string QueryName { get; set; }
        public string ConnectionString { get; set; }
        public string Querydata { get; set; }
        [MaxLength(50)]
        public string QuerytemplateName { get; set; }
        [Column("OrderID", TypeName = "decimal")]
        public decimal? OrderId { get; set; }
        public int? MergeId { get; set; }
    }
}
