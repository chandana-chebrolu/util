﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TrustMe.Models
{
    public partial class Role
    {
        public int RoleId { get; set; }
        [Required]
        [MaxLength(80)]
        public string RoleName { get; set; }
        [MaxLength(200)]
        public string RoleDescription { get; set; }
        public bool IsActive { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        [MaxLength(30)]
        public string CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }
        [MaxLength(30)]
        public string ModifiedBy { get; set; }
    }
}
