﻿export class Item {
    constructor(
        //public Id: number,
       
        
        public Ecode: string,
       
        public Password: string

        //public  DeptId: number,
     
        //public FirstName: string,
      
        //public LastName: string,
      
        //public DateOfBirth: string,
     
        //public DateOfJoin: string,


        //public EmailId: string,

        //public MobileNumber: number,

        //public AltMobileNumber: number,

        //public  IsActive: boolean,


        //public  CreatedDate: string,
            
        //public CreatedBy: string,

     
        //public ModifiedDate: string,
       
        //public ModifiedBy: string,
        //public ProjectId: number,
        //public  CanExport: boolean,
        //public  Address: string,
      
        //public  StgUserId: string,
       
        //public PrdUserId: string




    ) { }
}