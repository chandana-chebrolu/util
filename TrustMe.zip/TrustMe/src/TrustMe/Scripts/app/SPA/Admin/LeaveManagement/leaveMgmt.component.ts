import { Component } from '@angular/core';

@Component({
    templateUrl: 'app/SPA/Admin/LeaveManagement/leaveMgmt-detail.component.html'
})
export class leaveMgmtComponent {
    public pageTitle: string = 'LeaveManagement';
}