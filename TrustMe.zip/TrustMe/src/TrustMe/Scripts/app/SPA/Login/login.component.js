System.register(['@angular/core', '@angular/router', "./login.service"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, login_service_1;
    var LoginComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (login_service_1_1) {
                login_service_1 = login_service_1_1;
            }],
        execute: function() {
            LoginComponent = (function () {
                function LoginComponent(loginService, _router) {
                    this.loginService = loginService;
                    this._router = _router;
                    this.pageTitle = 'Login';
                    this.logged = { ECode: '' };
                }
                LoginComponent.prototype.ngOnInit = function () {
                    //this._loginService.getEmployees().subscribe(employees => this.employees = employees,
                    //    error => this.errorMessage = <any>error);
                };
                LoginComponent.prototype.login = function (Ecode, Password) {
                    var _this = this;
                    this.loginService.validateLogin(Ecode, Password)
                        .subscribe(function (response) {
                        _this.response = response;
                        if (response[0].response) {
                            _this.logged.ECode = Ecode;
                            _this.loginService.setLogged(_this.logged);
                            alert('Login Success');
                            //let navigationExtras: NavigationExtras = {
                            //    queryParams: {
                            //    }
                            //};
                            var id = response[0].id;
                            _this._router.navigate(['/utilizationEntry', id]);
                        }
                        else {
                            alert('Invalid Login');
                        }
                    });
                    console.log(Ecode);
                };
                LoginComponent = __decorate([
                    core_1.Component({
                        template: "\n    <div>\n    <div class=\"col-lg-10 col-md-10 col-sm-10\">\n    <div class=\"panel panel-primary\">\n    <div class=\"panel-heading\">Login </div>\n    <div class=\"panel-body\">\n    <div class=\"container-fluid\">\n    <div class=\"form-group\">\n    <div class=\"row\">\n    <label class=\"col-md-2 control-label\">Username </label>\n    <div class=\"col-md-3\">\n    <div class=\"input-group\">\n    <span class=\"input-group-addon\">FN </span>\n    <input id=\"Ecode\" name=\"Ecode\"  placeholder=\"Enter ECode\" [(ngModel)]=\"Ecode\"  class=\"form-control\" required=\"\" type=\"text\" />\n    </div>\n    <span class=\"help-block\" > </span>\n    </div>\n    <div class=\"col-md-1 errorMessage\">\n    <span class=\"help-inline \">Enter Username</span>\n    </div>\n    </div>\n    </div>   \n    <div class=\"form-group\">\n    <div class=\"row\">\n    <label class=\"col-md-2 control-label\"  for=\"password\"> Password </label>\n        <div class=\"col-md-3\">\n        <div class=\"input-group\">\n        <input placeholder=\"Enter Password\" class=\"form-control\" [(ngModel)]=\"Password\" required=\"\" type=\"password\" >\n    </div>\n    <span class=\"help-block\" > </span>\n        </div>\n        <div class=\"col-md-1 errorMessage\" >\n            <span class=\"help-inline \"> Enter Password</span>\n                </div>\n                </div>\n\n                </div>\n                </div>\n\n                </div>\n                <div class=\"panel-footer\">\n                    <div class=\"row\">\n                        <div class=\"col-md-2\">\n                            </div>\n                            <div class=\"col-md-3\">\n                                <button id=\"button1id\" name= \"button1id\" class=\"btn btn-primary\" (click)=\"login(Ecode,Password)\" > Sign In</button>\n<button id=\"\" name= \"\" class=\"btn btn-danger\" (click)=\"testpst()\"> Clear </button>\n    </div>\n    <div class=\"col-md-3 pull-right\">\n        <a id=\"btnChngPwd\" name= \"singlebutton\" class=\"btn\"> Change Password</a>\n            </div>\n</div>\n            </div>\n            </div>\n            </div>\n            </div>\n",
                        providers: [login_service_1.LoginService]
                    }), 
                    __metadata('design:paramtypes', [login_service_1.LoginService, router_1.Router])
                ], LoginComponent);
                return LoginComponent;
            }());
            exports_1("LoginComponent", LoginComponent);
        }
    }
});
