System.register(['@angular/core', '@angular/forms', './UtilizationEntry.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, forms_1, UtilizationEntry_service_1;
    var InsertUtilizationComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (forms_1_1) {
                forms_1 = forms_1_1;
            },
            function (UtilizationEntry_service_1_1) {
                UtilizationEntry_service_1 = UtilizationEntry_service_1_1;
            }],
        execute: function() {
            InsertUtilizationComponent = (function () {
                function InsertUtilizationComponent(_utilizationEntryService, _fb) {
                    this._utilizationEntryService = _utilizationEntryService;
                    this._fb = _fb;
                    this.selDep = 'One';
                    this.selEmp = 'One';
                    this.selPrj = 'One';
                    this.selTask = 'One';
                    this.selTC = 'One';
                    this.date = '2017-11-01 16:33:17.533';
                    this.createdDate = '2017-11-01';
                }
                InsertUtilizationComponent.prototype.ngOnInit = function () {
                    var _this = this;
                    this.myForm = this._fb.group({
                        Ecode: [],
                        timeSpent: [],
                        comments: [],
                        departments: this._utilizationEntryService.GetAllDepartments().subscribe(function (Departments) {
                            _this.departments = Departments;
                        }),
                        employees: this._utilizationEntryService.GetAllEmployees().subscribe(function (Employees) {
                            _this.employees = Employees;
                        }),
                        projects: this._utilizationEntryService.GetAllProjects().subscribe(function (Projects) {
                            _this.projects = Projects;
                        }),
                        taskCategory: this._utilizationEntryService.GetTaskCategory().subscribe(function (TaskCategory) {
                            _this.taskCategory = TaskCategory;
                        }),
                        tasks: this._utilizationEntryService.GetTasks().subscribe(function (Tasks) {
                            _this.tasks = Tasks;
                        })
                    });
                };
                InsertUtilizationComponent.prototype.onChange = function (newDepValue) {
                    console.log(newDepValue);
                    this.selDep = newDepValue;
                };
                InsertUtilizationComponent.prototype.onEmpChange = function (newEmpValue) {
                    console.log(newEmpValue);
                    this.selEmp = newEmpValue;
                };
                InsertUtilizationComponent.prototype.onPrjChange = function (newPrjValue) {
                    console.log(newPrjValue);
                    this.selPrj = newPrjValue;
                };
                InsertUtilizationComponent.prototype.onTaskChange = function (newTaskValue) {
                    console.log(newTaskValue);
                    this.selTask = newTaskValue;
                };
                InsertUtilizationComponent.prototype.onTCChange = function (newTCValue) {
                    console.log(newTCValue);
                    this.selTC = newTCValue;
                };
                InsertUtilizationComponent.prototype.save = function (model, isValid) {
                    // call API to save        // ...
                    //this._utilizationEntryService.PostUtilizationEntry(model).subscribe(
                    //        (
                    //            response => {
                    //                this.response = response;
                    //                if (response[0].response) {
                    //                    alert('Entry Successful');
                    //                }
                    //                else {
                    //                    alert('Invalid Details');
                    //                }
                    //            }
                    //        )
                    //        );
                    console.log(model, isValid);
                };
                InsertUtilizationComponent = __decorate([
                    core_1.Component({
                        templateUrl: 'app/SPA/UtilizationEntry/InsertEntryUtilization.component.html',
                        providers: [UtilizationEntry_service_1.UtilizationEntryService]
                    }), 
                    __metadata('design:paramtypes', [UtilizationEntry_service_1.UtilizationEntryService, forms_1.FormBuilder])
                ], InsertUtilizationComponent);
                return InsertUtilizationComponent;
            }());
            exports_1("InsertUtilizationComponent", InsertUtilizationComponent);
        }
    }
});
