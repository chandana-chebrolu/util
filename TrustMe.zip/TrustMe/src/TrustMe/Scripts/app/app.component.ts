﻿import {Component} from
"@angular/core";
@Component({
    selector: "opengamelist",
    template: `
        <div class="site-body container-background">
        <div class="container-fluid">
            <div class="row">
<a [routerLink]="['/login']">
                <img src="http://v-snune01:9097/Assets/styles/images/headerLogo.jpg" />
</a>
            </div>
            <!-- ngInclude:  -->
            <div class="row ">
                <nav class="navbar navbar-inverse nav-border ng-scope">
                    <div class="container">
                        <ul class="nav navbar-nav ng-hide">
                            <li class="nav-item-border"><a [routerLink]="['/home']">Home</a></li>
                            <li class="dropdown nav-item-border">
                                <a class="dropdown-toggle" data-toggle="dropdown" role="button"  [routerLink]="['/utilizationEntry',id]">Utilization</a>                                
                            </li>
                            <li class="dropdown nav-item-border">
                                <a [routerLink] = "['/utilizationReport']" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Utilization Report</a>                               
                            </li>                           
                            <li class="dropdown nav-item-border">
                                <a  [routerLink] = "['/employeeInfo']"  class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Employee Info</a>
                              </li>
                            <li class="dropdown nav-item-border">
                                <a [routerLink] = "['/leaveMgmt']"  class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Leave Management</a>                               
                            </li>
                            <li class="dropdown nav-item-border">
                                <a [routerLink] = "['/lookUpInfo']"  class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">LookUp Info</a>                               
                            </li>
                              <li class="dropdown nav-item-border">
                                <a [routerLink] = "['/taskExpertise']" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">TaskExpertise</a>                               
                            </li>
 <li class="dropdown nav-item-border">
                                <a [routerLink] = "['/testData']" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">TestData</a>                               
                            </li>

                        </ul>
                        <ul class="nav navbar-nav navbar-right ng-hide">
                            <li><a>Hi, <b class="ng-binding"></b>- <b class="ng-binding"></b></a></li>
                            <li class="nav-item-border"><a>Logout</a></li>
                        </ul>
                    </div>
                </nav>
            </div>
            <!-- ngView:  -->
            <div class="container ">
 <router-outlet></router-outlet>
             </div>
       </div>
    </div>
    `
})
export class AppComponent {
    title = "Utilization";
}