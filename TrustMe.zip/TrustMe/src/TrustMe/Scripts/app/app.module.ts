﻿///<reference path="../../typings/index.d.ts"/>
import {NgModule} from "@angular/core";
import {BrowserModule} from "@angular/platform-browser";
import {HttpModule} from "@angular/http";
import { FormsModule, ReactiveFormsModule  } from '@angular/forms';
import { RouterModule } from '@angular/router';

import "rxjs/Rx";
import {AppComponent} from "./app.component";
import { LoginComponent }  from "./SPA/login/login.component";
import { homeComponent } from "./SPA/Home/home.component";
import { utilizationEntryComponent } from './SPA/utilizationEntry/utilizationEntry.component';
import { utilizationReportComponent } from './SPA/utilizationReport/utilizationReport.component';
import { employeeInfoComponent } from './SPA/Admin/EmployeeInfo/employeeInfo.component';
import { leaveMgmtComponent } from './SPA/Admin/LeaveManagement/leaveMgmt.component';
import { lookUpInfoComponent } from './SPA/Admin/LookUpInfo/lookUpInfo.component';
import { taskExpertiseComponent } from './SPA/Admin/TaskExpertise/taskExpertise.component';
import { InsertUtilizationComponent} from './SPA/UtilizationEntry/InsertEntryUtilization.component';


@NgModule({
    // directives, components, and pipes
    declarations: [
        AppComponent,
        LoginComponent,
        homeComponent,
        utilizationEntryComponent,
        utilizationReportComponent,
        employeeInfoComponent,
        leaveMgmtComponent,
        lookUpInfoComponent,
        taskExpertiseComponent,
        InsertUtilizationComponent
    ],
    // modules
    imports: [
        BrowserModule,
        HttpModule,
        FormsModule,
        ReactiveFormsModule,
        RouterModule
            .forRoot
            ([
                { path: 'login', component: LoginComponent },
                { path: 'home', component: homeComponent },
                { path: 'utilizationEntry/:id', component: utilizationEntryComponent },
                { path: 'utilizationReport', component: utilizationReportComponent },
                { path: 'employeeInfo', component: employeeInfoComponent },
                { path: 'lookUpInfo', component: lookUpInfoComponent },
                { path: 'leaveMgmt', component: leaveMgmtComponent },
                { path: 'taskExpertise', component: taskExpertiseComponent },
                { path: 'testData', component: InsertUtilizationComponent },
                { path: '', redirectTo: 'login', pathMatch: 'full' },
                { path: '**', redirectTo: 'login', pathMatch: 'full' }
            ])
    ],
    // providers
    providers: [
        
    ],
    bootstrap: [
        AppComponent
    ]
})
export class AppModule {}