﻿import {Injectable} from "@angular/core";
import {Http, Response, Headers, RequestOptions, URLSearchParams } from "@angular/http";
import {Observable } from "rxjs/Rx";
import {Item} from "./item";
import {IResponse} from "./response";

@Injectable()
export class ItemService {
    constructor(private http: Http) { }
    private baseUrl = "api/values/";  // web api URL
 
    // calls the [GET] /api/items/GetLatest/{n} Web API method to retrieve the latest items.
    getLatest(fncode: string, Password: string): Observable<IResponse[]>{       
       
       
        let headers = new Headers({ 'Content-Type': 'application/json' }); // ... Set content type to JSON
        
        let options = new RequestOptions({ headers: headers }); // Create a request option
        var data = { Ecode: fncode, Password: Password }
        console.log(data);        

        var url = this.baseUrl + "/getEmp"
        return this.http.post(url, data, options)
            .map((response: Response) => <IResponse[]>response.json())
            .do(res => console.log('All: ' + JSON.stringify(res))
            );
    }    
}