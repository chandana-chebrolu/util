﻿export interface IResponse {
    response: boolean;
    id: number,
}