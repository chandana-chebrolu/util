﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using TrustMe.Models;
using Newtonsoft.Json;

// For more information on enabling Web API for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace TrustMe.Controllers
{
    public class getDep
    {
        public int DeptId { get; set; }
        public string DeptName { get; set; }

        public string Ecode { get; set; }
    }
    public class getEmp
    {
        public string Ecode { get; set; }
        public string Name { get; set; }
    }
    public class getPrj
    {
        public int ProjectId { get; set; }
        public string ProjectName { get; set; }

        public bool? IsActive { get; set; }
    }
    public class getTaskCat
    {
        public int TaskCategoryId { get; set; }
        public string taskCategory { get; set; }

        public bool? IsActive { get; set; }
    }
    public class getTasks
    {
        public int DeptId { get; set; }
        public int TaskId { get; set; }
        public string TaskName { get; set; }
        public string TaskDescription { get; set; }
    }
    public class getUtilizationEntryByDate
    {
        public int Id { get; set; }
        public string Ecode { get; set; }
        public string Name { get; set; }
        public string ProjectName { get; set; }
        public int ProjectId { get; set; }
        public string Department { get; set; }
        public int DeptId { get; set; }
        public DateTime Date { get; set; }
        public string Task { get; set; }
        public decimal TimeSpent { get; set; }
        public string Comments { get; set; }
        public string TaskCategory { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public string ModifiedBy { get; set; }
        public string Status { get; set; }
        public string DeletedBy { get; set; }
    }

    [Route("api/UtilizationEntry")]
    public class UtilizationEntryController : Controller
    {
        // GET: api/values
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/values/5
        [HttpPost]
        [Route("GetDepartments")]
        public IEnumerable<getDep> GetDepartments([FromBody] Employee empId)
        {
            Models.APIAppDbContext c = new APIAppDbContext();
            List<getDep> query = c.Employee.Join(c.Department, emp => emp.DeptId, dep => dep.DeptId, (emp, dep) =>
               new getDep() { DeptId = dep.DeptId, DeptName = dep.DeptName, Ecode = emp.Ecode })
             .Where(postAndMeta => postAndMeta.Ecode == empId.Ecode).ToList();
            return query;
        }
      
        [HttpGet]
        [Route("GetAllDepartments")]
        public IEnumerable<getDep> GetAllDepartments()
        {
            Models.APIAppDbContext c = new APIAppDbContext();
            IEnumerable<getDep> query = c.Department.Select(p => new getDep
            {
                DeptId = p.DeptId,
                DeptName = p.DeptName
            });
            return query;
        }
        [HttpGet]
        [Route("GetAllEmployees")]
        public IEnumerable<getEmp> GetAllEmployees()
        {
            Models.APIAppDbContext c = new APIAppDbContext();
            IEnumerable<getEmp> query = c.Employee.Select(p => new getEmp
            {
                Ecode = p.Ecode,
                Name = p.FirstName + p.LastName
            });
            return query;
        }
        [HttpGet]
        [Route("GetAllProjects")]
        public IEnumerable<getPrj> GetAllProjects()
        {
            Models.APIAppDbContext c = new APIAppDbContext();
            IEnumerable<getPrj> query = c.Project.Select(p => new getPrj
            {
                ProjectId = p.ProjectId,
                ProjectName = p.ProjectName,
                IsActive = p.IsActive
            }).Where(p => p.IsActive.Value == true);
            return query;
        }
        [HttpGet]
        [Route("GetTaskCategory")]
        public IEnumerable<getTaskCat> GetTaskCategory()
        {
            Models.APIAppDbContext c = new APIAppDbContext();
            IEnumerable<getTaskCat> query = c.TaskCategory.Select(p => new getTaskCat
            {
                TaskCategoryId = p.TaskCategoryId,
                taskCategory = p.Description,
                IsActive = p.IsActive
            }).Where(p => p.IsActive.Value == true);
            return query;
        }
        [HttpGet]
        [Route("GetTasks")]
        public IEnumerable<getTasks> GetTasks()
        {
            APIAppDbContext c = new APIAppDbContext();
            IEnumerable<getTasks> query = c.Task.Select(p => new getTasks
            {
                TaskId = p.TaskId,
                TaskName = p.TaskName,
                TaskDescription = p.TaskDescription,
                DeptId = p.DeptId
            });
            return query;
        }
        [HttpPost]
        [Route("GetEmpDetailsById")]
        public IEnumerable<getUtilizationEntryByDate> GetEmpDetailsById([FromBody] Employee empId)
        {
            Models.APIAppDbContext c = new APIAppDbContext();
            List<getUtilizationEntryByDate> query = c.Employee.Join(c.Department, emp => emp.DeptId, dep => dep.DeptId, (emp, dep) =>
               new { emp, dep })
               .Join(c.Project, emp1 => emp1.emp.ProjectId, p => p.ProjectId, (emp1, p) =>
               new { emp1, p })
                .Select(m => new getUtilizationEntryByDate
                {
                    Department = m.emp1.dep.DeptName,
                    DeptId = m.emp1.dep.DeptId,
                    Name = m.emp1.emp.FirstName + m.emp1.emp.LastName,
                    Ecode = m.emp1.emp.Ecode,
                    ProjectName = m.p.ProjectName,
                    ProjectId = m.p.ProjectId,
                    Id = m.emp1.emp.Id
                }
                )
             .Where(postAndMeta => postAndMeta.Id == empId.Id).ToList();
            return query;
        }
        [HttpPost]
        [Route("PostUtilizationEntry")]
        public IEnumerable<dynamic> PostUtilizationEntry([FromBody] UtilizationReport empId)
        {
            APIAppDbContext c = new APIAppDbContext();
            c.UtilizationReport.Add(empId);
            c.SaveChanges();
            yield return new { response = true };

        }
        [HttpPost]
        [Route("GetUtilizationEntryByDate")]
        public IEnumerable<getUtilizationEntryByDate> GetUtilizationEntryByDate([FromBody] UtilizationReport selDate)
        {
            APIAppDbContext c = new APIAppDbContext();
            IEnumerable<getUtilizationEntryByDate> UR = c.UtilizationReport
                .Where(x => x.Date.ToString("yyyy/MM/dd") == selDate.Date.ToString("yyyy/MM/dd"))
                .Select(p => new getUtilizationEntryByDate
                {
                    Id = p.Id,
                    Ecode = p.Ecode,
                    Name = p.Name,
                    Department = p.Department,
                    TaskCategory = p.TaskCategory,
                    Date = p.Date,
                    TimeSpent = p.TimeSpent

                });
            return UR;

        }
        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
