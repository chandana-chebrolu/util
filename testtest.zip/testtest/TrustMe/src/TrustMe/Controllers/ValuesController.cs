﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using TrustMe.Models;
using Newtonsoft.Json;
using System.Runtime.Serialization;

namespace TrustMe.Controllers
{
	[Route("api/Values")]
   
	public class ValuesController : Controller
	{
		// GET api/values
		
		[HttpGet]
		[Route("Get")]
		public IEnumerable<string> Get()
		{
			Models.APIAppDbContext c=new APIAppDbContext();
			IQueryable<Role> query = c.Role;
			var json = JsonConvert.SerializeObject(query);
			yield return json.ToString();
		}
		[HttpGet]
		[Route("getEmp")]
		// GET api/values/
		
		public IEnumerable<string> getEmp()
		{
			Models.APIAppDbContext c = new APIAppDbContext();
			IQueryable<Employee> query = c.Employee;
			var json = JsonConvert.SerializeObject(query);
			yield return json.ToString();
		}

		// POST api/values
		[HttpPost]
		[Route("validateLogin")]
		public IEnumerable<dynamic> validateLogin([FromBody] Employee a)
		{
			var response = false;
			Models.APIAppDbContext c = new APIAppDbContext();
			var query = c.Employee.Where(f => f.Ecode == a.Ecode).Where(x => x.Password == a.Password).ToList();

			if (query.Count>=1)
			{
				yield return new { response = true, id = query[0].Id };
			}
			else
			{
				yield return new { response = response, id = 0 };
			}
		}

        [HttpPost]
        [Route("testpst")]
        public void testpst()
        {

        }


        // PUT api/values/5
        [HttpPut("{id}")]
		public void Put(int id, [FromBody]string value)
		{
		}

		// DELETE api/values/5
		[HttpDelete("{id}")]
		public void Delete(int id)
		{
		}
	}
}
