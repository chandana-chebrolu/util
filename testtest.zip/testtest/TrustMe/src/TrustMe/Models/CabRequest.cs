﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TrustMe.Models
{
    public partial class CabRequest
    {
        public int Id { get; set; }
        [Required]
        [Column("ECode")]
        [MaxLength(20)]
        public string Ecode { get; set; }
        [Required]
        [Column("EName")]
        [MaxLength(100)]
        public string Ename { get; set; }
        public int? DeptId { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? Date { get; set; }
        public TimeSpan? CabEntryTime { get; set; }
        [MaxLength(10)]
        public string Address { get; set; }
        public bool? PickUp { get; set; }
        public bool? Escort { get; set; }
        public bool? OverrideAddress { get; set; }
    }
}
