﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TrustMe.Models
{
    public partial class ShiftReport
    {
        public int Id { get; set; }
        [Required]
        [Column("ECode")]
        [MaxLength(20)]
        public string Ecode { get; set; }
        [Required]
        [MaxLength(100)]
        public string Name { get; set; }
        [MaxLength(100)]
        public string Department { get; set; }
        [Column(TypeName = "date")]
        public DateTime? ShiftStartDate { get; set; }
        [Column(TypeName = "time(5)")]
        public TimeSpan? ShiftStartTime { get; set; }
        [Column(TypeName = "date")]
        public DateTime? ShiftEndDate { get; set; }
        [Column(TypeName = "time(5)")]
        public TimeSpan? ShiftEndTime { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        [MaxLength(20)]
        public string CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }
        [MaxLength(20)]
        public string ModifiedBy { get; set; }
        [MaxLength(10)]
        public string Status { get; set; }
        [Column(TypeName = "varchar(max)")]
        public string Reason { get; set; }
        [MaxLength(20)]
        public string ApprovedBy { get; set; }
        public bool? WorkFromHome { get; set; }
        public bool? IsRelease { get; set; }
        [MaxLength(250)]
        public string ShiftType { get; set; }
    }
}
