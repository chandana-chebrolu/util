﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TrustMe.Models
{
    public partial class UtilizationReport
    {
        public int Id { get; set; }
        [Required]
        [Column("ECode")]
        [MaxLength(20)]
        public string Ecode { get; set; }
        [Required]
        [MaxLength(100)]
        public string Name { get; set; }
        [MaxLength(30)]
        public string Project { get; set; }
        [Required]
        [MaxLength(100)]
        public string Department { get; set; }
        [Required]
        [MaxLength(50)]
        public string TaskCategory { get; set; }
        [Column(TypeName = "date")]
        public DateTime Date { get; set; }
        [Required]
        [MaxLength(100)]
        public string Task { get; set; }
        [Column(TypeName = "decimal")]
        public decimal TimeSpent { get; set; }
        [Required]
        [MaxLength(1000)]
        public string Comments { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        [MaxLength(20)]
        public string CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }
        [MaxLength(20)]
        public string ModifiedBy { get; set; }
        [MaxLength(10)]
        public string Status { get; set; }
        [MaxLength(50)]
        public string DeletedBy { get; set; }
    }
}
