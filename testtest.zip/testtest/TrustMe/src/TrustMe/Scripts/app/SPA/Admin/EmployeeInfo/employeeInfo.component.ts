import { Component } from '@angular/core';

@Component({
    templateUrl: 'app/SPA/Admin/EmployeeInfo/employeeInfo-detail.component.html'
})
export class employeeInfoComponent {
    public pageTitle: string = 'employeeInfo';
}