import { Component } from '@angular/core';

@Component({
    templateUrl: 'app/SPA/Admin/LookUpInfo/lookUpInfo-detail.component.html'
})
export class lookUpInfoComponent {
    public pageTitle: string = 'lookUpInfo';
}