import { Component,EventEmitter, Output} from '@angular/core';
import {CORE_DIRECTIVES, FORM_DIRECTIVES} from '@angular/common';


@Component({
    templateUrl: 'app/SPA/Admin/TaskExpertise/taskexpertise-detail.component.html',
    directives: [CORE_DIRECTIVES, FORM_DIRECTIVES]

})



export class taskExpertiseComponent {
    public pageTitle: string = 'taskExpertise';
    public myCar: any;
}