import { Component } from '@angular/core';

@Component({
    templateUrl: 'app/SPA/Home/home-detail.component.html'
})
export class homeComponent {
    public pageTitle: string = 'Home';
}
