
import { Component, OnInit, Input } from '@angular/core';
import { ILogin } from './login';
import { IResponse} from "../../response";
import {Router, NavigationExtras} from '@angular/router';
import {LoginService} from "./login.service";

@Component({
    template: `
    <div>
    <div class="col-lg-10 col-md-10 col-sm-10">
    <div class="panel panel-primary">
    <div class="panel-heading">Login </div>
    <div class="panel-body">
    <div class="container-fluid">
    <div class="form-group">
    <div class="row">
    <label class="col-md-2 control-label">Username </label>
    <div class="col-md-3">
    <div class="input-group">
    <span class="input-group-addon">FN </span>
    <input id="Ecode" name="Ecode"  placeholder="Enter ECode" [(ngModel)]="Ecode"  class="form-control" required="" type="text" />
    </div>
    <span class="help-block" > </span>
    </div>
    <div class="col-md-1 errorMessage">
    <span class="help-inline ">Enter Username</span>
    </div>
    </div>
    </div>   
    <div class="form-group">
    <div class="row">
    <label class="col-md-2 control-label"  for="password"> Password </label>
        <div class="col-md-3">
        <div class="input-group">
        <input placeholder="Enter Password" class="form-control" [(ngModel)]="Password" required="" type="password" >
    </div>
    <span class="help-block" > </span>
        </div>
        <div class="col-md-1 errorMessage" >
            <span class="help-inline "> Enter Password</span>
                </div>
                </div>

                </div>
                </div>

                </div>
                <div class="panel-footer">
                    <div class="row">
                        <div class="col-md-2">
                            </div>
                            <div class="col-md-3">
                                <button id="button1id" name= "button1id" class="btn btn-primary" (click)="login(Ecode,Password)" > Sign In</button>
<button id="" name= "" class="btn btn-danger" (click)="testpst()"> Clear </button>
    </div>
    <div class="col-md-3 pull-right">
        <a id="btnChngPwd" name= "singlebutton" class="btn"> Change Password</a>
            </div>
</div>
            </div>
            </div>
            </div>
            </div>
`,
    providers: [LoginService]
})
export class LoginComponent implements OnInit {
    public pageTitle: string = 'Login';
    errorMessage: string;
    response: IResponse[];
    private logged: ILogin = {ECode: '' };


    constructor(private loginService: LoginService, private _router: Router) {

    }
    ngOnInit(): void {
        //this._loginService.getEmployees().subscribe(employees => this.employees = employees,
        //    error => this.errorMessage = <any>error);
    }
    login(Ecode, Password) {
        this.loginService.validateLogin(Ecode, Password)
            .subscribe(
            response => {
                this.response = response;
                if (response[0].response) {
                    this.logged.ECode = Ecode;
                    this.loginService.setLogged(this.logged);
                    alert('Login Success');
                    //let navigationExtras: NavigationExtras = {
                    //    queryParams: {
                    //    }
                    //};
                    var id = response[0].id;
                    this._router.navigate(['/utilizationEntry', id]);
                }
                else {
                    alert('Invalid Login');
                    //this.status = "Invalid Login";
                }
            }
            );
        console.log(Ecode);
    }
}
