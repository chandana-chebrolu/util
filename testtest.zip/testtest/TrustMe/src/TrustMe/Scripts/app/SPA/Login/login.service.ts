﻿import { Injectable} from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import {IResponse} from "../../response";

import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/map';

import 'rxjs/add/operator/map';

import { ILogin } from './login';

@Injectable()
export class LoginService {
    private logged: ILogin;
    private subject: Subject<ILogin> = new Subject<ILogin>();

    constructor(private _http: Http) {
    }
    private baseUrl = "api/values/";  // web api URL


    validateLogin(fncode: string, Password: string): Observable<IResponse[]> {
        let headers = new Headers({ 'Content-Type': 'application/json' }); // ... Set content type to JSON

        let options = new RequestOptions({ headers: headers }); // Create a request option
        var data = { Ecode: "FN"+fncode, Password: Password }
        console.log(data);

        var url = this.baseUrl + "/validateLogin"
        return this._http.post(url, data, options)
            .map((response: Response) => <IResponse[]>response.json())
            .do(res => console.log('All: ' + JSON.stringify(res))
            );
    }

    private handleError(error: Response) {
        console.log(error);
        return Observable.throw(error.json().error || 'Server error');
    }

    setLogged(logged: ILogin): void {
        this.logged = logged;
        this.subject.next(logged);
    }

    getLogged(): Observable<ILogin> {
        return this.subject.asObservable();
    }

}