﻿import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { IUtilizationEntry } from './UtilizationEntry';
import { UtilizationEntryService } from './UtilizationEntry.service';
import { IResponse} from "../../response";

@Component({
    templateUrl: 'app/SPA/UtilizationEntry/InsertEntryUtilization.component.html',
    providers: [UtilizationEntryService]
})
export class InsertUtilizationComponent implements OnInit {
    public myForm: FormGroup; 
    departments: IUtilizationEntry[];
    employees: IUtilizationEntry[];
    projects: IUtilizationEntry[];
    taskCategory: IUtilizationEntry[];
    tasks: IUtilizationEntry[];
    utilizationEntry: Array<IUtilizationEntry>;
    selDep = 'One';
    selEmp = 'One';
    selPrj = 'One';
    selTask = 'One';
    selTC = 'One';
    response: IResponse[];

    constructor(private _utilizationEntryService: UtilizationEntryService, private _fb: FormBuilder) {

    }

    ngOnInit(): void {
        this.myForm = this._fb.group({
            Ecode: [],
            timeSpent: [],
            comments : [],
            departments : this._utilizationEntryService.GetAllDepartments().subscribe(
                Departments => {
                    this.departments = Departments
                }),
           employees: this._utilizationEntryService.GetAllEmployees().subscribe(
                Employees => {
                    this.employees = Employees;
                }),
           projects: this._utilizationEntryService.GetAllProjects().subscribe(
                Projects => {
                    this.projects = Projects;
                }),
           taskCategory: this._utilizationEntryService.GetTaskCategory().subscribe(
                TaskCategory => {
                    this.taskCategory = TaskCategory;
                }),
           tasks: this._utilizationEntryService.GetTasks().subscribe(
                Tasks => {
                    this.tasks = Tasks;
                })
        }); 
               
    }
    onChange(newDepValue) {
        console.log(newDepValue);
        this.selDep = newDepValue;
    }
    onEmpChange(newEmpValue) {
        console.log(newEmpValue);
        this.selEmp = newEmpValue;
    }
    onPrjChange(newPrjValue) {
        console.log(newPrjValue);
        this.selPrj = newPrjValue;
    }
    onTaskChange(newTaskValue) {
        console.log(newTaskValue);
        this.selTask = newTaskValue;
    }
    onTCChange(newTCValue) {
        console.log(newTCValue);
        this.selTC = newTCValue;
    }
    date: string = '2017-11-01 16:33:17.533';
    createdDate: string = '2017-11-01';

    save(model: IUtilizationEntry, isValid: boolean) {
        // call API to save        // ...

        //this._utilizationEntryService.PostUtilizationEntry(model).subscribe(
        //        (
        //            response => {
        //                this.response = response;
        //                if (response[0].response) {
        //                    alert('Entry Successful');
        //                }
        //                else {
        //                    alert('Invalid Details');
        //                }
        //            }
        //        )
        //        );
       
        console.log(model, isValid);
    }
    
    
}