﻿import { Injectable} from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import {IUtilizationEntry} from "./UtilizationEntry";
import {IResponse} from "../../response";

import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/map';


@Injectable()
export class UtilizationEntryService {

    constructor(private _http: Http) {
    }
    private baseUrl = "api/UtilizationEntry/";  // web api URL
  
    GetDepartments(fncode: string): Observable<IUtilizationEntry[]> {
        let headers = new Headers({ 'Content-Type': 'application/json' }); // ... Set content type to JSON
        let options = new RequestOptions({ headers: headers }); // Create a request option
        var data = { Ecode: 'FN44543'}

        var url = this.baseUrl + "/GetDepartments"
        return this._http.post(url, data, options)
            .map((response: Response) => <IUtilizationEntry[]>response.json()  );
    }
    GetAllDepartments(): Observable<IUtilizationEntry[]> {
        var url = this.baseUrl + "/GetAllDepartments";
        return this._http.get(url)
            .map((response: Response) => <IUtilizationEntry[]>response.json())
            .catch(this.handleError);
    }
    GetAllEmployees(): Observable<IUtilizationEntry[]> {
        var url = this.baseUrl + "/GetAllEmployees";
        return this._http.get(url)
            .map((response: Response) => <IUtilizationEntry[]>response.json())
            .catch(this.handleError);
    }
    GetAllProjects(): Observable<IUtilizationEntry[]> {
        var url = this.baseUrl + "/GetAllProjects";
        return this._http.get(url)
            .map((response: Response) => <IUtilizationEntry[]>response.json())
            .catch(this.handleError);
    }
    GetTaskCategory(): Observable<IUtilizationEntry[]> {
        var url = this.baseUrl + "/GetTaskCategory";
        return this._http.get(url)
            .map((response: Response) => <IUtilizationEntry[]>response.json())
            .catch(this.handleError);
    }
    GetTasks(): Observable<IUtilizationEntry[]> {
        var url = this.baseUrl + "/GetTasks";
        return this._http.get(url)
            .map((response: Response) => <IUtilizationEntry[]>response.json())
            .catch(this.handleError);
    }
    PostUtilizationEntry(fncode: string, Name: string, Project: string, Department: string, TaskCategory: string,
        Date: string, Task: string, TimeSpent: string, Comments: string, CreatedDate: string, CreatedBy: string,
        Status: string): Observable<IResponse[]> {
        let headers = new Headers({ 'Content-Type': 'application/json' }); // ... Set content type to JSON
        let options = new RequestOptions({ headers: headers }); // Create a request option
        var data = {
            Ecode: fncode, Name: Name, Project: Project, Department: Department, TaskCategory: TaskCategory,
            Date: Date, Task: Task, TimeSpent: TimeSpent, Comments: Comments, CreatedDate: CreatedDate,
            CreatedBy: CreatedBy,Status: Status
        }
        var url = this.baseUrl + "/PostUtilizationEntry"
        return this._http.post(url, data, options)
            .map((response: Response) => <IResponse[]>response.json())
            .do(res => console.log('All: ' + JSON.stringify(res))
            );
    }

    GetUtilizationEntryByDate(selDate: string): Observable<IUtilizationEntry[]> {
        let headers = new Headers({ 'Content-Type': 'application/json' }); // ... Set content type to JSON
        let options = new RequestOptions({ headers: headers }); // Create a request option
        var data = {
            Date: selDate 
        }
        console.log(data);
        var url = this.baseUrl + "/GetUtilizationEntryByDate"
        return this._http.post(url, data, options)
            .map((response: Response) => <IUtilizationEntry[]>response.json())
            .do(res => console.log('All: ' + JSON.stringify(res))
            );
    }

    GetEmpDetailsById(id: number): Observable<IUtilizationEntry[]> {
        let headers = new Headers({ 'Content-Type': 'application/json' }); // ... Set content type to JSON
        let options = new RequestOptions({ headers: headers }); // Create a request option
        var data = {
            Id: id
        }
        console.log(data);
        var url = this.baseUrl + "/GetEmpDetailsById"
        return this._http.post(url, data, options)
            .map((response: Response) => <IUtilizationEntry[]>response.json())
            .do(res => console.log('All: ' + JSON.stringify(res))
            );
    }

    private handleError(error: Response) {
        console.log(error);
        return Observable.throw(error.json().error || 'Server error');
    }


}