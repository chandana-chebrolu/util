﻿export interface IUtilizationEntry {
    deptId: number;
    deptName: string;
    ecode: string;
    name: string;
    projectId: number;
    projectName?: string;
    IsActive?: boolean;
    TaskCategoryId?: number;
    TaskId?: number;
    taskName?: string;
    TaskDescription?: string,
    Comments?: string,
    CreatedBy?: string,
    CreatedDate?: string,
    Date?: string,
    department?: string,
    Project?: string,
    Status?: string,
    Task?: string,
    taskCategory?: string,
    TimeSpent?: string,
}