System.register(['@angular/core', './UtilizationEntry.service', '../login/login.service', '@angular/router'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, UtilizationEntry_service_1, login_service_1, router_1;
    var utilizationEntryComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (UtilizationEntry_service_1_1) {
                UtilizationEntry_service_1 = UtilizationEntry_service_1_1;
            },
            function (login_service_1_1) {
                login_service_1 = login_service_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            }],
        execute: function() {
            utilizationEntryComponent = (function () {
                function utilizationEntryComponent(_utilizationEntryService, ls, _route, _router) {
                    this._utilizationEntryService = _utilizationEntryService;
                    this.ls = ls;
                    this._route = _route;
                    this._router = _router;
                    this.lookupData = { deptId: 0, deptName: '', ecode: '', name: '', projectId: 0, projectName: '' };
                    this.Disabled = true;
                    this.pageTitle = 'utilizationEntry';
                    this.selDep = 'One';
                    this.selEmp = 'One';
                    this.selPrj = 'one';
                    this.selTask = 'one';
                    this.selTC = 'one';
                    this.date = '2017-11-01 16:33:17.533';
                    this.createdDate = '2017-11-01';
                }
                utilizationEntryComponent.prototype.ngOnInit = function () {
                    var _this = this;
                    var id = this._route.snapshot.params['id'];
                    //this._utilizationEntryService.GetDepartments('').subscribe
                    //    (utilizationEntry => {
                    //        this.utilizationEntry = utilizationEntry;
                    //    },
                    //    error => this.errorMessage = <any>error);
                    this._utilizationEntryService.GetAllDepartments().subscribe(function (Departments) {
                        _this.departments = Departments;
                    });
                    this._utilizationEntryService.GetAllEmployees().subscribe(function (Employees) {
                        _this.employees = Employees;
                    });
                    this._utilizationEntryService.GetAllProjects().subscribe(function (Projects) {
                        _this.projects = Projects;
                    });
                    this._utilizationEntryService.GetTaskCategory().subscribe(function (TaskCategory) {
                        _this.taskCategory = TaskCategory;
                        _this.selTC = TaskCategory[0].taskCategory;
                    });
                    this._utilizationEntryService.GetTasks().subscribe(function (Tasks) {
                        _this.tasks = Tasks;
                        _this.selTask = Tasks[0].taskName;
                    });
                    this._utilizationEntryService.GetUtilizationEntryByDate('2017-11-01').subscribe(function (GridUtilizationEntry) {
                        _this.gridUtilizationEntry = GridUtilizationEntry;
                    });
                    this._utilizationEntryService.GetEmpDetailsById(id).subscribe(function (LookupData) {
                        _this.lookupData.ecode = LookupData[0].ecode;
                        _this.lookupData.name = LookupData[0].name;
                        _this.lookupData.deptId = LookupData[0].deptId;
                        _this.lookupData.projectId = LookupData[0].projectId;
                        _this.lookupData.department = LookupData[0].department;
                        _this.lookupData.projectName = LookupData[0].projectName;
                        _this.Ecode = LookupData[0].ecode;
                        _this.selDep = LookupData[0].department;
                        _this.selEmp = LookupData[0].name;
                        _this.selPrj = LookupData[0].projectName;
                    });
                };
                utilizationEntryComponent.prototype.onChange = function (newDepValue) {
                    console.log(newDepValue);
                    this.selDep = newDepValue;
                };
                utilizationEntryComponent.prototype.onEmpChange = function (newEmpValue) {
                    console.log(newEmpValue);
                    this.selEmp = newEmpValue;
                };
                utilizationEntryComponent.prototype.onPrjChange = function (newPrjValue) {
                    console.log(newPrjValue);
                    this.selPrj = newPrjValue;
                };
                utilizationEntryComponent.prototype.onTaskChange = function (newTaskValue) {
                    console.log(newTaskValue);
                    this.selTask = newTaskValue;
                };
                utilizationEntryComponent.prototype.onTCChange = function (newTCValue) {
                    console.log(newTCValue);
                    this.selTC = newTCValue;
                };
                utilizationEntryComponent.prototype.InsertUtilizationEntry = function (Ecode, timeSpent, comments) {
                    var _this = this;
                    console.log("Sample - entry");
                    console.log(this.selDep);
                    this._utilizationEntryService.PostUtilizationEntry(Ecode, this.selEmp, this.selPrj, this.selDep, this.selTC, this.createdDate, this.selTask, timeSpent, comments, this.date, Ecode, 'Submitted').subscribe((function (response) {
                        _this.response = response;
                        if (response[0].response) {
                            alert('Entry Successful');
                            _this._utilizationEntryService.GetUtilizationEntryByDate('2017-11-01').subscribe(function (GridUtilizationEntry) {
                                _this.gridUtilizationEntry = GridUtilizationEntry;
                            });
                        }
                        else {
                            alert('Invalid Details');
                        }
                    }));
                };
                utilizationEntryComponent = __decorate([
                    core_1.Component({
                        template: "\n<div>\n    <div class=\"row\">\n        <div class=\"col-lg-12 col-md-12 col-sm-12\">\n            <div class=\"panel panel-primary\">\n                <div class=\"panel-heading\">Enter Utilization Information</div>\n                <div class=\"panel-body\">\n                    <div class=\"container-fluid\">\n                        <div class=\"row\">\n                            <div class=\"col-md-2\">\n                            </div>\n                            <div class=\"col-md-2\">\n                                <input type=\"checkbox\" >   Fill for Others\n                                <span class=\"help-block\"> </span>\n                            </div>\n                            <div class=\"col-md-2\">\n\n                            </div>\n                            <div class=\"col-md-2\">\n                            </div>\n                            <div class=\"col-md-2\">\n\n                            </div>\n                            <div class=\"col-md-2\">\n\n                            </div>\n                        </div>\n                        <div class=\"row\">\n                            <div class=\"col-md-2\">\n                                <label class=\"control-label\">Department</label>\n                            </div>\n                            <div class=\"col-md-2\">\n                                <select class=\"form-control\" (change)=\"onChange($event.target.value)\" [disabled]=\"Disabled\">\n                                     <option *ngFor=\"let dep of departments\"  [selected]=\"dep.deptId == lookupData.deptId\" >\n    {{dep.deptName}}\n  </option>\n                                </select>\n                                <span class=\"help-block\"> </span>\n                            </div>\n                            <div class=\"col-md-2 errorMessage\">\n                                <span class=\"help-inline tip-content\">Select Department</span>\n                            </div>\n\n                            <div class=\"col-md-2\">\n                                <label class=\"control-label\" for=\"selectbasic\">Date </label>\n                            </div>\n                            <div class=\"col-md-2\">\n                                <p class=\"input-group\">\n                                    <input type=\"text\" name=\"txtdate\" class=\"form-control\"  required ng-class=\"{true: 'error'}[submitted && UtilizationEntry_form.txtdate.$invalid  && submittedval===true]\" ng-change=\"selectDate(dt)\" />\n                                    <span class=\"input-group-btn\">\n                                        <button type=\"button\" class=\"btn btn-default\" ><i class=\"glyphicon glyphicon-calendar\"></i></button>\n                                    </span>\n                                </p>\n                            </div>\n                            <div class=\"col-md-2 errorMessage\">\n                                <span class=\"help-inline tip-content\" >Date Required</span>\n                            </div>\n                        </div>\n\n                        <div class=\"row\">\n\n                            <div class=\"col-md-2\">\n                                <label class=\"control-label\" for=\"selectbasic\">Name </label>\n                                <span class=\"help-block\"> </span>\n                            </div>\n                            <div class=\"col-md-2\">\n                                <select class=\"form-control \" (change)=\"onEmpChange($event.target.value)\" [disabled]=\"Disabled\">\n <option *ngFor=\"let emp of employees\" [selected]=\"emp.ecode == lookupData.ecode\">\n    {{emp.name}}\n  </option>                                   \n                                </select>\n\n                            </div>\n                            <div class=\"col-md-2\">\n                                <span class=\"help-inline tip-content\">Select Name</span>\n                            </div>\n\n                            <div class=\"col-md-2\">\n                                <label class=\"control-label\" for=\"selectbasic\">Task Category</label>\n                            </div>\n                            <div class=\"col-md-2\">\n                                <select class=\"form-control \" (change)=\"onTCChange($event.target.value)\">\n                                     <option *ngFor=\"let tc of taskCategory\" >\n    {{tc.taskCategory}}\n  </option>\n                                </select>\n                                <span class=\"help-block\"> </span>\n                            </div>\n                            <div class=\"col-md-2 errorMessage\">\n                                <span class=\"help-inline tip-content\">Select TaskCategory</span>\n                            </div>\n                        </div>\n                        <div class=\"row\">\n                            <div class=\"col-md-2\">\n                                <label class=\"control-label\" for=\"selectbasic\">Ecode </label>\n\n                            </div>\n                            <div class=\"col-md-2\">\n                                <input id=\"textinputecode\" name=\"textinputecode\" placeholder=\"ecode\" [disabled]=\"true\"  [(ngModel)]=\"Ecode\" class=\"form-control input-md\" required=\"\" type=\"text\" >\n                                <span class=\"help-block\"> </span>\n                            </div>\n                            <div class=\"col-md-2\">\n\n                            </div>\n\n                            <div class=\"col-md-2\">\n                                <label class=\"control-label\" for=\"selectbasic\">Task / FR No's</label>\n                            </div>\n                            <div class=\"col-md-2\">\n                                <select class=\"form-control\" (change)=\"onTaskChange($event.target.value)\">\n                                     <option *ngFor=\"let tsk of tasks\">\n    {{tsk.taskName}}\n  </option>\n                                </select>\n                                <span class=\"help-block\"> </span>\n                            </div>\n                            <div class=\"col-md-2 errorMessage\">\n                                <span class=\"help-inline tip-content\">Select TaskNos</span>\n                            </div>\n                        </div>\n\n\n                        <div class=\"row\">\n                            <div class=\"col-md-2\">\n                                <label class=\"control-label\" for=\"selectbasic\">Project</label>\n                                <span class=\"help-block\"> </span>\n                            </div>\n                            <div class=\"col-md-2\">\n                                <select class=\"form-control\"  (change)=\"onPrjChange($event.target.value)\">\n                                   <option *ngFor=\"let prj of projects\" [selected]=\"prj.projectId == lookupData.projectId\">\n    {{prj.projectName}}\n  </option>\n                                </select>\n                                <span class=\"help-block\"> </span>\n                            </div>\n                            <div class=\"col-md-2 errorMessage\">\n                                <span class=\"help-inline tip-content\">Select Project</span>\n                            </div>\n\n                            <div class=\"col-md-2\">\n                                <label class=\"control-label\" for=\"selectbasic\">Time Spent</label>\n                            </div>\n                            <div class=\"col-md-1\">\n                                <input id=\"textinputtime\" [(ngModel)]=\"timeSpent\" name=\"textinputtime\" placeholder=\"Hrs\" class=\"form-control input-md\" maxlength=\"4\" required type=\"text\" data-ng-model=\"Timespent\" >\n                                <span class=\"help-block\"></span>\n                            </div>\n                            <div class=\"col-md-3 errorMessage\">\n                                <span class=\"help-inline tip-content\">Time Required</span>\n                            </div>\n                        </div>\n                        <div class=\"row\">\n                            <div class=\"col-md-2\">\n                                <label class=\"control-label\" for=\"selectbasic\">Comments</label>\n                            </div>\n                            <div class=\"col-md-8\">\n                                <textarea class=\"form-control\" id=\"textarea\" name=\"textarea\" [(ngModel)]=\"comments\" ></textarea>\n                                <span class=\"help-block\"> </span>\n                            </div>\n                        </div>\n                    </div>\n                </div>\n                <div class=\"panel-footer\">\n                    <div class=\"row\">\n                        <div class=\"col-md-3\">\n                        </div>\n                        <div class=\"col-md-3\">\n                            &nbsp;<button id=\"btnSaveUtil\" name=\"singlebutton\" class=\"btn btn-primary\" (click)=\"InsertUtilizationEntry(Ecode,timeSpent,comments)\">Save</button>\n                            &nbsp;&nbsp;\n                            <button id=\"btncancelUtil\" name=\"singlebutton\" class=\"btn btn-danger\" >Clear</button>\n                        </div>\n                        <div class=\"col-md-1\">\n                        </div>\n                        <div class=\"col-md-4\">\n                            <div style=\"font-family: times; font-style: italic; font-size: 125%; color: brown; width: 70%;\" align=\"center\">\n                              \n                            </div>\n                        </div>\n                        <div class=\"col-md-1\">\n                        </div>\n                    </div>\n                </div>\n            </div>\n            <div class=\"row\">\n                <div class=\"col-md-12\">\n                    <div class=\"table-responsive\">\n    <table class=\"table\" *ngIf ='gridUtilizationEntry && gridUtilizationEntry.length'>\n        <thead>\n            <tr>\n                <th>\n                    Ecode\n                </th>\n                <th>Name</th>\n                <th>Department</th>\n                <th>TaskCategory</th>\n                <th>Date</th>\n                <th>TimeSpent</th>\n                </tr>\n            </thead>\n            <tbody>\n                <tr *ngFor = 'let UE of gridUtilizationEntry'>                    \n                    <td>{{UE.ecode}}</td>\n                    <td>{{UE.name}}</td>\n                    <td>{{UE.department}}</td>\n<td>{{UE.taskCategory}}</td>\n<td>{{UE.date}}</td>\n<td>{{UE.timeSpent}}</td>\n                </tr>\n                </tbody>\n        </table>\n    </div>\n                </div>\n            </div>\n        </div>\n    </div>\n</div>\n",
                        providers: [login_service_1.LoginService, UtilizationEntry_service_1.UtilizationEntryService]
                    }), 
                    __metadata('design:paramtypes', [UtilizationEntry_service_1.UtilizationEntryService, login_service_1.LoginService, router_1.ActivatedRoute, router_1.Router])
                ], utilizationEntryComponent);
                return utilizationEntryComponent;
            }());
            exports_1("utilizationEntryComponent", utilizationEntryComponent);
        }
    }
});
