import { Component, OnInit } from '@angular/core';
import { IUtilizationEntry } from './UtilizationEntry';
import { UtilizationEntryService } from './UtilizationEntry.service';
import { IResponse} from "../../response";
import { LoginService} from '../login/login.service';
import { ILogin } from '../login/login';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
    template:
    `
<div>
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="panel panel-primary">
                <div class="panel-heading">Enter Utilization Information</div>
                <div class="panel-body">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-2">
                            </div>
                            <div class="col-md-2">
                                <input type="checkbox" >   Fill for Others
                                <span class="help-block"> </span>
                            </div>
                            <div class="col-md-2">

                            </div>
                            <div class="col-md-2">
                            </div>
                            <div class="col-md-2">

                            </div>
                            <div class="col-md-2">

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2">
                                <label class="control-label">Department</label>
                            </div>
                            <div class="col-md-2">
                                <select class="form-control" (change)="onChange($event.target.value)" [disabled]="Disabled">
                                     <option *ngFor="let dep of departments"  [selected]="dep.deptId == lookupData.deptId" >
    {{dep.deptName}}
  </option>
                                </select>
                                <span class="help-block"> </span>
                            </div>
                            <div class="col-md-2 errorMessage">
                                <span class="help-inline tip-content">Select Department</span>
                            </div>

                            <div class="col-md-2">
                                <label class="control-label" for="selectbasic">Date </label>
                            </div>
                            <div class="col-md-2">
                                <p class="input-group">
                                    <input type="text" name="txtdate" class="form-control"  required ng-class="{true: 'error'}[submitted && UtilizationEntry_form.txtdate.$invalid  && submittedval===true]" ng-change="selectDate(dt)" />
                                    <span class="input-group-btn">
                                        <button type="button" class="btn btn-default" ><i class="glyphicon glyphicon-calendar"></i></button>
                                    </span>
                                </p>
                            </div>
                            <div class="col-md-2 errorMessage">
                                <span class="help-inline tip-content" >Date Required</span>
                            </div>
                        </div>

                        <div class="row">

                            <div class="col-md-2">
                                <label class="control-label" for="selectbasic">Name </label>
                                <span class="help-block"> </span>
                            </div>
                            <div class="col-md-2">
                                <select class="form-control " (change)="onEmpChange($event.target.value)" [disabled]="Disabled">
 <option *ngFor="let emp of employees" [selected]="emp.ecode == lookupData.ecode">
    {{emp.name}}
  </option>                                   
                                </select>

                            </div>
                            <div class="col-md-2">
                                <span class="help-inline tip-content">Select Name</span>
                            </div>

                            <div class="col-md-2">
                                <label class="control-label" for="selectbasic">Task Category</label>
                            </div>
                            <div class="col-md-2">
                                <select class="form-control " (change)="onTCChange($event.target.value)">
                                     <option *ngFor="let tc of taskCategory" >
    {{tc.taskCategory}}
  </option>
                                </select>
                                <span class="help-block"> </span>
                            </div>
                            <div class="col-md-2 errorMessage">
                                <span class="help-inline tip-content">Select TaskCategory</span>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2">
                                <label class="control-label" for="selectbasic">Ecode </label>

                            </div>
                            <div class="col-md-2">
                                <input id="textinputecode" name="textinputecode" placeholder="ecode" [disabled]="true"  [(ngModel)]="Ecode" class="form-control input-md" required="" type="text" >
                                <span class="help-block"> </span>
                            </div>
                            <div class="col-md-2">

                            </div>

                            <div class="col-md-2">
                                <label class="control-label" for="selectbasic">Task / FR No's</label>
                            </div>
                            <div class="col-md-2">
                                <select class="form-control" (change)="onTaskChange($event.target.value)">
                                     <option *ngFor="let tsk of tasks">
    {{tsk.taskName}}
  </option>
                                </select>
                                <span class="help-block"> </span>
                            </div>
                            <div class="col-md-2 errorMessage">
                                <span class="help-inline tip-content">Select TaskNos</span>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-md-2">
                                <label class="control-label" for="selectbasic">Project</label>
                                <span class="help-block"> </span>
                            </div>
                            <div class="col-md-2">
                                <select class="form-control"  (change)="onPrjChange($event.target.value)">
                                   <option *ngFor="let prj of projects" [selected]="prj.projectId == lookupData.projectId">
    {{prj.projectName}}
  </option>
                                </select>
                                <span class="help-block"> </span>
                            </div>
                            <div class="col-md-2 errorMessage">
                                <span class="help-inline tip-content">Select Project</span>
                            </div>

                            <div class="col-md-2">
                                <label class="control-label" for="selectbasic">Time Spent</label>
                            </div>
                            <div class="col-md-1">
                                <input id="textinputtime" [(ngModel)]="timeSpent" name="textinputtime" placeholder="Hrs" class="form-control input-md" maxlength="4" required type="text" data-ng-model="Timespent" >
                                <span class="help-block"></span>
                            </div>
                            <div class="col-md-3 errorMessage">
                                <span class="help-inline tip-content">Time Required</span>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2">
                                <label class="control-label" for="selectbasic">Comments</label>
                            </div>
                            <div class="col-md-8">
                                <textarea class="form-control" id="textarea" name="textarea" [(ngModel)]="comments" ></textarea>
                                <span class="help-block"> </span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="panel-footer">
                    <div class="row">
                        <div class="col-md-3">
                        </div>
                        <div class="col-md-3">
                            &nbsp;<button id="btnSaveUtil" name="singlebutton" class="btn btn-primary" (click)="InsertUtilizationEntry(Ecode,timeSpent,comments)">Save</button>
                            &nbsp;&nbsp;
                            <button id="btncancelUtil" name="singlebutton" class="btn btn-danger" >Clear</button>
                        </div>
                        <div class="col-md-1">
                        </div>
                        <div class="col-md-4">
                            <div style="font-family: times; font-style: italic; font-size: 125%; color: brown; width: 70%;" align="center">
                              
                            </div>
                        </div>
                        <div class="col-md-1">
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="table-responsive">
    <table class="table" *ngIf ='gridUtilizationEntry && gridUtilizationEntry.length'>
        <thead>
            <tr>
                <th>
                    Ecode
                </th>
                <th>Name</th>
                <th>Department</th>
                <th>TaskCategory</th>
                <th>Date</th>
                <th>TimeSpent</th>
                </tr>
            </thead>
            <tbody>
                <tr *ngFor = 'let UE of gridUtilizationEntry'>                    
                    <td>{{UE.ecode}}</td>
                    <td>{{UE.name}}</td>
                    <td>{{UE.department}}</td>
<td>{{UE.taskCategory}}</td>
<td>{{UE.date}}</td>
<td>{{UE.timeSpent}}</td>
                </tr>
                </tbody>
        </table>
    </div>
                </div>
            </div>
        </div>
    </div>
</div>
`,
    providers: [LoginService, UtilizationEntryService]
})
export class utilizationEntryComponent implements OnInit {
    departments: IUtilizationEntry[];
    employees: IUtilizationEntry[];
    projects: IUtilizationEntry[];
    taskCategory: IUtilizationEntry[];
    tasks: IUtilizationEntry[];
    utilizationEntry: Array<IUtilizationEntry>;
    gridUtilizationEntry: IUtilizationEntry[];
    lookupData: IUtilizationEntry = { deptId: 0, deptName: '', ecode: '', name: '', projectId: 0, projectName: ''};
    errorMessage: string;
    Ecode: string;
    Disabled: boolean = true;
    public pageTitle: string = 'utilizationEntry';
    selDep = 'One';
    selEmp = 'One';
    selPrj = 'one';
    selTask = 'one';
    selTC = 'one';
    response: IResponse[];
    private logged: ILogin;
    
    constructor(private _utilizationEntryService: UtilizationEntryService, private ls: LoginService,
        private _route: ActivatedRoute,private _router: Router) {
    }
    ngOnInit(): void {
        var id = this._route.snapshot.params['id'];
        
        //this._utilizationEntryService.GetDepartments('').subscribe
        //    (utilizationEntry => {
        //        this.utilizationEntry = utilizationEntry;
        //    },
        //    error => this.errorMessage = <any>error);
       
        

        this._utilizationEntryService.GetAllDepartments().subscribe(
            Departments => {
                this.departments = Departments
            });
        this._utilizationEntryService.GetAllEmployees().subscribe(
            Employees => {
                this.employees = Employees;
            });
        this._utilizationEntryService.GetAllProjects().subscribe(
            Projects => {
                this.projects = Projects;
            });
        this._utilizationEntryService.GetTaskCategory().subscribe(
            TaskCategory => {
                this.taskCategory = TaskCategory;
                this.selTC = TaskCategory[0].taskCategory;
            });
        this._utilizationEntryService.GetTasks().subscribe(
            Tasks => {
                this.tasks = Tasks;
                this.selTask = Tasks[0].taskName;
            });
        this._utilizationEntryService.GetUtilizationEntryByDate('2017-11-01').subscribe(
            GridUtilizationEntry => {
                this.gridUtilizationEntry = GridUtilizationEntry;
            });
        this._utilizationEntryService.GetEmpDetailsById(id).subscribe(
            LookupData => {
                this.lookupData.ecode = LookupData[0].ecode;
                this.lookupData.name = LookupData[0].name;
                this.lookupData.deptId = LookupData[0].deptId;
                this.lookupData.projectId = LookupData[0].projectId;
                this.lookupData.department = LookupData[0].department;
                this.lookupData.projectName = LookupData[0].projectName;
                this.Ecode = LookupData[0].ecode;
                this.selDep = LookupData[0].department;
                this.selEmp = LookupData[0].name;
                this.selPrj = LookupData[0].projectName;
            });         
    }
   
    onChange(newDepValue) {
        console.log(newDepValue);
        this.selDep = newDepValue;
    }
    onEmpChange(newEmpValue) {
        console.log(newEmpValue);
        this.selEmp = newEmpValue;
    }
    onPrjChange(newPrjValue) {
        console.log(newPrjValue);
        this.selPrj = newPrjValue;
    }
    onTaskChange(newTaskValue) {
        console.log(newTaskValue);
        this.selTask = newTaskValue;
    }
    onTCChange(newTCValue) {
        console.log(newTCValue);
        this.selTC = newTCValue;
    }

    date: string = '2017-11-01 16:33:17.533';
    createdDate: string = '2017-11-01';
    InsertUtilizationEntry(Ecode, timeSpent, comments) {
        console.log("Sample - entry");
        console.log(this.selDep);
        this._utilizationEntryService.PostUtilizationEntry(Ecode, this.selEmp, this.selPrj, this.selDep, this.selTC,
            this.createdDate, this.selTask, timeSpent, comments, this.date, Ecode, 'Submitted').subscribe(
            (
                response => {
                    this.response = response;
                    if (response[0].response) {
                        alert('Entry Successful');
                        this._utilizationEntryService.GetUtilizationEntryByDate('2017-11-01').subscribe(
                            GridUtilizationEntry => {
                                this.gridUtilizationEntry = GridUtilizationEntry;
                            });
                    }
                    else {
                        alert('Invalid Details');
                    }
                }
            )
            );
    }
    
}