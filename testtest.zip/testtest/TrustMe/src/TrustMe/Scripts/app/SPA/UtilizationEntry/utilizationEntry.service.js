System.register(['@angular/core', '@angular/http', 'rxjs/Observable', 'rxjs/add/operator/catch', 'rxjs/add/operator/do', 'rxjs/add/operator/map'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, http_1, Observable_1;
    var UtilizationEntryService;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (http_1_1) {
                http_1 = http_1_1;
            },
            function (Observable_1_1) {
                Observable_1 = Observable_1_1;
            },
            function (_1) {},
            function (_2) {},
            function (_3) {}],
        execute: function() {
            UtilizationEntryService = (function () {
                function UtilizationEntryService(_http) {
                    this._http = _http;
                    this.baseUrl = "api/UtilizationEntry/"; // web api URL
                }
                UtilizationEntryService.prototype.GetDepartments = function (fncode) {
                    var headers = new http_1.Headers({ 'Content-Type': 'application/json' }); // ... Set content type to JSON
                    var options = new http_1.RequestOptions({ headers: headers }); // Create a request option
                    var data = { Ecode: 'FN44543' };
                    var url = this.baseUrl + "/GetDepartments";
                    return this._http.post(url, data, options)
                        .map(function (response) { return response.json(); });
                };
                UtilizationEntryService.prototype.GetAllDepartments = function () {
                    var url = this.baseUrl + "/GetAllDepartments";
                    return this._http.get(url)
                        .map(function (response) { return response.json(); })
                        .catch(this.handleError);
                };
                UtilizationEntryService.prototype.GetAllEmployees = function () {
                    var url = this.baseUrl + "/GetAllEmployees";
                    return this._http.get(url)
                        .map(function (response) { return response.json(); })
                        .catch(this.handleError);
                };
                UtilizationEntryService.prototype.GetAllProjects = function () {
                    var url = this.baseUrl + "/GetAllProjects";
                    return this._http.get(url)
                        .map(function (response) { return response.json(); })
                        .catch(this.handleError);
                };
                UtilizationEntryService.prototype.GetTaskCategory = function () {
                    var url = this.baseUrl + "/GetTaskCategory";
                    return this._http.get(url)
                        .map(function (response) { return response.json(); })
                        .catch(this.handleError);
                };
                UtilizationEntryService.prototype.GetTasks = function () {
                    var url = this.baseUrl + "/GetTasks";
                    return this._http.get(url)
                        .map(function (response) { return response.json(); })
                        .catch(this.handleError);
                };
                UtilizationEntryService.prototype.PostUtilizationEntry = function (fncode, Name, Project, Department, TaskCategory, Date, Task, TimeSpent, Comments, CreatedDate, CreatedBy, Status) {
                    var headers = new http_1.Headers({ 'Content-Type': 'application/json' }); // ... Set content type to JSON
                    var options = new http_1.RequestOptions({ headers: headers }); // Create a request option
                    var data = {
                        Ecode: fncode, Name: Name, Project: Project, Department: Department, TaskCategory: TaskCategory,
                        Date: Date, Task: Task, TimeSpent: TimeSpent, Comments: Comments, CreatedDate: CreatedDate,
                        CreatedBy: CreatedBy, Status: Status
                    };
                    var url = this.baseUrl + "/PostUtilizationEntry";
                    return this._http.post(url, data, options)
                        .map(function (response) { return response.json(); })
                        .do(function (res) { return console.log('All: ' + JSON.stringify(res)); });
                };
                UtilizationEntryService.prototype.GetUtilizationEntryByDate = function (selDate) {
                    var headers = new http_1.Headers({ 'Content-Type': 'application/json' }); // ... Set content type to JSON
                    var options = new http_1.RequestOptions({ headers: headers }); // Create a request option
                    var data = {
                        Date: selDate
                    };
                    console.log(data);
                    var url = this.baseUrl + "/GetUtilizationEntryByDate";
                    return this._http.post(url, data, options)
                        .map(function (response) { return response.json(); })
                        .do(function (res) { return console.log('All: ' + JSON.stringify(res)); });
                };
                UtilizationEntryService.prototype.GetEmpDetailsById = function (id) {
                    var headers = new http_1.Headers({ 'Content-Type': 'application/json' }); // ... Set content type to JSON
                    var options = new http_1.RequestOptions({ headers: headers }); // Create a request option
                    var data = {
                        Id: id
                    };
                    console.log(data);
                    var url = this.baseUrl + "/GetEmpDetailsById";
                    return this._http.post(url, data, options)
                        .map(function (response) { return response.json(); })
                        .do(function (res) { return console.log('All: ' + JSON.stringify(res)); });
                };
                UtilizationEntryService.prototype.handleError = function (error) {
                    console.log(error);
                    return Observable_1.Observable.throw(error.json().error || 'Server error');
                };
                UtilizationEntryService = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [http_1.Http])
                ], UtilizationEntryService);
                return UtilizationEntryService;
            }());
            exports_1("UtilizationEntryService", UtilizationEntryService);
        }
    }
});
