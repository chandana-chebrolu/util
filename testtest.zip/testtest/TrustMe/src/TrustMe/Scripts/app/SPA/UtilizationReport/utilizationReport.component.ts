import { Component } from '@angular/core';

@Component({
    templateUrl: 'app/SPA/utilizationReport/utilizationReport.component.html'
})
export class utilizationReportComponent {
    public pageTitle: string = 'utilizationReport';
}