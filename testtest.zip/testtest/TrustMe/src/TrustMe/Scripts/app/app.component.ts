﻿import {Component} from
"@angular/core";
@Component({
    selector: "opengamelist",
    template: `
        <div class="site-body container-background">
        <div class="container-fluid">
            <div class="row">
<a [routerLink]="['/login']">
                <img src="http://v-snune01:9097/Assets/styles/images/headerLogo.jpg" />
</a>
            </div>
            <!-- ngInclude:  -->
            <div class="row ">
                <nav class="navbar navbar-inverse nav-border ng-scope">
                    <div class="container">
                        <ul class="nav navbar-nav ng-hide">
                            <li class="nav-item-border"><a [routerLink]="['/home']">Home</a></li>
                            <li class="dropdown nav-item-border">
                                <a class="dropdown-toggle" data-toggle="dropdown" role="button"  [routerLink]="['/utilizationEntry',id]">Utilization</a>                                
                            </li>                          

                        </ul>
                        
                    </div>
                </nav>
            </div>
            <!-- ngView:  -->
            <div class="container ">
 <router-outlet></router-outlet>
             </div>
       </div>
    </div>
    `
})
export class AppComponent {
    title = "Utilization";
}