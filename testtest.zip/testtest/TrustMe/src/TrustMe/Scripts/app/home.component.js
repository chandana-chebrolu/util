System.register(["@angular/core", "./item.service", '@angular/router'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, item_service_1, router_1;
    var HomeComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (item_service_1_1) {
                item_service_1 = item_service_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            }],
        execute: function() {
            HomeComponent = (function () {
                function HomeComponent(itemService, _router) {
                    this.itemService = itemService;
                    this._router = _router;
                    this.pageTitle = '';
                }
                HomeComponent.prototype.ngOnInit = function () {
                    //this.itemService.getLatest()
                    //    .subscribe(
                    //    latestItems => this.items = JSON.parse(latestItems),
                    //        error => this.errorMessage = <any>error);
                };
                HomeComponent.prototype.Login = function (fncode, pwd) {
                    //this.itemService.getLatest(fncode, pwd)
                    //          .subscribe(
                    //         items => this.items = JSON.parse(items),
                    //    error => this.errorMessage = <any>error
                    //);
                    //    console.log(this.items);
                };
                HomeComponent.prototype.getLatest = function (Ecode, Password) {
                    var _this = this;
                    // console.log(Ecode, Password);
                    this.itemService.getLatest(Ecode, Password)
                        .subscribe(function (response) {
                        _this.response = response;
                        if (response[0].response) {
                            _this.status = "Login Success";
                            alert('Login Success');
                            _this._router.navigate(['/about']);
                        }
                        else {
                            _this.status = "Invalid Login";
                        }
                    });
                };
                HomeComponent = __decorate([
                    core_1.Component({
                        template: "\n            <div class=\"form-group\">\n<h3>{{status}}</h3>\n                <div class=\"input-group\">\n                    <span class=\"input-group-addon\" id=\"basic-addon1\"><span class=\"glyphicon glyphicon-user\"></span></span>\n                    <input type=\"text\" class=\"form-control\" placeholder=\"Author\" [(ngModel)]=\"Ecode\" name=\"author\">\n                </div>\n                <br />\n                <textarea class=\"form-control\" rows=\"3\" placeholder=\"Text\" [(ngModel)]=\"Password\" name=\"text\"></textarea>\n                <br />\n                <button  type=\"submit\" class=\"btn btn-primary btn-block\" (click)=\"getLatest(Ecode,Password)\">Add</button>\n                <button  type=\"submit\" class=\"btn btn-warning btn-block\">Update</button>\n            </div>           \n    ",
                        providers: [item_service_1.ItemService],
                        styles: ["\n        ul.items li {\n            cursor: pointer;\n        }\n        ul.items li.selected {\n            background-color: #cccccc;\n        }\n    "]
                    }), 
                    __metadata('design:paramtypes', [item_service_1.ItemService, router_1.Router])
                ], HomeComponent);
                return HomeComponent;
            }());
            exports_1("HomeComponent", HomeComponent);
        }
    }
});
