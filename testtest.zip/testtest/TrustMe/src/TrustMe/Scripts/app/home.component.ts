﻿import {Component, OnInit, Input} from "@angular/core";
import {Item} from "./item";
import {ItemService} from "./item.service";
import { EmitterService } from './emitter.service';
import {Observable} from 'rxjs/Rx';
import { IResponse} from "./response";
import {Router} from '@angular/router';

@Component({
    template: `
            <div class="form-group">
<h3>{{status}}</h3>
                <div class="input-group">
                    <span class="input-group-addon" id="basic-addon1"><span class="glyphicon glyphicon-user"></span></span>
                    <input type="text" class="form-control" placeholder="Author" [(ngModel)]="Ecode" name="author">
                </div>
                <br />
                <textarea class="form-control" rows="3" placeholder="Text" [(ngModel)]="Password" name="text"></textarea>
                <br />
                <button  type="submit" class="btn btn-primary btn-block" (click)="getLatest(Ecode,Password)">Add</button>
                <button  type="submit" class="btn btn-warning btn-block">Update</button>
            </div>           
    `,
    providers: [ItemService],
    styles: [`
        ul.items li {
            cursor: pointer;
        }
        ul.items li.selected {
            background-color: #cccccc;
        }
    `]
})
export class HomeComponent implements OnInit {
    pageTitle: string = '';
    items: Item[];
    status: string;
    errorMessage: string;
    response: IResponse[];
    constructor(private itemService: ItemService, private _router: Router) { }

    ngOnInit() {
        //this.itemService.getLatest()
        //    .subscribe(
        //    latestItems => this.items = JSON.parse(latestItems),
        //        error => this.errorMessage = <any>error);
    }
    Login(fncode: string, pwd: string) {

        //this.itemService.getLatest(fncode, pwd)
        //          .subscribe(
        //         items => this.items = JSON.parse(items),
        //    error => this.errorMessage = <any>error
        //);
        //    console.log(this.items);
    }
    getLatest(Ecode, Password) {
        // console.log(Ecode, Password);
        this.itemService.getLatest(Ecode, Password)
            .subscribe(
            response => {
                this.response = response;
                if (response[0].response) {
                    this.status = "Login Success";
                    alert('Login Success');
                    this._router.navigate(['/about']);
                }
                else {
                    this.status = "Invalid Login";
                }
            }
            );
    }

    //submitComment(event, value: string) {
    //    console.log("msg");
    //    console.log(value);
    //    console.log(this.Ecode);
    //}











}