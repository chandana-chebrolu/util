﻿import {Component} from "@angular/core";
@Component({
    selector: "login",
    template: `
        <h2>{{title}}</h2>
        <div>
            TODO: Not implemented yet.
        </div>
    `
})
export class LoginComponent {
    title = "Login";
}